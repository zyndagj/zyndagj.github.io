#!/usr/bin/env python

import logging
logger = logging.getLogger(__name__)
FORMAT = "[%(levelname)s - root - %(funcName)s] %(message)s"
logging.basicConfig(level=logging.INFO, format=FORMAT)
import basicConfig, handler, basicConfig_noPropagate, handler_noPropagate

def main():
	info("info")
	debug("debug")
	warn("warn")
	basicConfig.info("info from basicConfig")
	basicConfig.debug("debug from basicConfig")
	basicConfig.warn("warn from basicConfig")
	basicConfig_noPropagate.info("info from basicConfig_noPropagate")
	basicConfig_noPropagate.debug("debug from basicConfig_noPropagate")
	basicConfig_noPropagate.warn("warn from basicConfig_noPropagate")
	handler.info("info from handler")
	handler.debug("debug from handler")
	handler.warn("warn from handler")
	handler_noPropagate.info("info from handler_noPropagate")
	handler_noPropagate.debug("debug from handler_noPropagate")
	handler_noPropagate.warn("warn from handler_noPropagate")

def info(msg):
	logger.info(msg)
def debug(msg):
	logger.debug(msg)
def warn(msg):
	logger.warn(msg)

if __name__ == "__main__":
	main()

