import logging
logger = logging.getLogger(__name__)
FORMAT = "[%(levelname)s - %(filename)s - %(funcName)s] %(message)s"

logging.basicConfig(level=logging.DEBUG, format=FORMAT)


def info(msg):
	logger.info(msg)
def debug(msg):
	logger.debug(msg)
def warn(msg):
	logger.warn(msg)
