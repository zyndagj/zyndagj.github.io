import logging
logger = logging.getLogger(__name__)
FORMAT = "[%(levelname)s - %(module)s - %(funcName)s] %(message)s"

logger.setLevel(logging.DEBUG)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter(FORMAT))
logger.addHandler(ch)

def info(msg):
	logger.info(msg)
def debug(msg):
	logger.debug(msg)
def warn(msg):
	logger.warn(msg)
