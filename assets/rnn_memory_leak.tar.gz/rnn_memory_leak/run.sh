#!/bin/bash

export OMP_NUM_THREADS=24
export KMP_AFFINITY='granularity=fine,compact,1,0'
export KMP_BLOCKTIME=0

python d4_example.py
python d4_example.py custom
python d4_example.py custom arith
TF_DISABLE_MKL=1 python d4_example.py
TF_DISABLE_MKL=1 python d4_example.py custom
TF_DISABLE_MKL=1 python d4_example.py custom arith
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" python d4_example.py
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" python d4_example.py custom
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" python d4_example.py custom arith
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" TF_DISABLE_MKL=1 python d4_example.py
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" TF_DISABLE_MKL=1 python d4_example.py custom
TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" TF_DISABLE_MKL=1 python d4_example.py custom arith

rm config_*tsv
[ -e results ] && rm -rf results
mkdir results
mv {mem,rate}_dnn*tsv results/
