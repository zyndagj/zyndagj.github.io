import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

mem = {}

# Read data
for lstm, td in ((1,1),(1,2),(2,1)):
	mem[(lstm, td)] = np.loadtxt('mem_lstm-%i_td-%i.tsv'%(lstm, td))
	print mem[(lstm,td)]
# Plot data
plt.figure(figsize=(10,5))
plt.suptitle("Effect of Layers on Leakage")

plt.subplot(1, 2, 1)
plt.title("Memory Usage")
for lstm, td in ((1,1),(1,2),(2,1)):
	vals = mem[(lstm,td)]/1000.0
	X = np.arange(len(vals))
	plt.plot(X[1:], vals[1:], label="lstm=%i td=%i"%(lstm,td))
plt.legend(loc=2)
ticks = np.arange(1,21,2)
plt.xticks(ticks, ticks)
plt.xlim(left=0)
plt.xlabel("Batch")
plt.ylabel("MB")

plt.subplot(1, 2, 2)
plt.title("Memory Increase")
for lstm, td in ((1,1),(1,2),(2,1)):
	vals = mem[(lstm,td)]/1000.0
	vdiff = np.diff(vals)
	X = np.arange(len(vdiff))+0.5
	plt.plot(X[1:], vdiff[1:], label="lstm=%i td=%i"%(lstm,td))
plt.legend(loc=1)
plt.xticks(ticks, ticks)
plt.xlim(left=0)
plt.xlabel("Batch")
plt.ylabel("MB")

plt.tight_layout()
plt.savefig("effect.png")
