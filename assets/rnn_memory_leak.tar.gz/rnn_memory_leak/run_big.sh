#!/bin/bash

export OMP_NUM_THREADS=24
export KMP_AFFINITY='granularity=fine,compact,1,0'
export KMP_BLOCKTIME=0


TF_XLA_FLAGS="--tf_xla_auto_jit=2 --tf_xla_cpu_global_jit" python d4_big.py custom > dnn_xla_custom.log
echo DNN+XLA+custom
TF_DISABLE_MKL=1 python d4_big.py custom > custom.log
echo custom
