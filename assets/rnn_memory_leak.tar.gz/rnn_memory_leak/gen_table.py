import os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

mem = {}

def fivenum(data):
	return np.percentile(data, [0, 25, 50, 75, 100], interpolation='midpoint')

# Read data
onoff = ('on','off')
header1 = '| DNN | XLA | Config | ArithOpt | Min | Q1 | Median | Q3 | Max | median(Rate) |'
header2 = '|:'+':|:'.join(['-']*10)+':|'
print header1
print header2
for dnn in onoff:
	for xla in onoff:
		for config in ('default','custom'):
			for opt in onoff:
				fname = 'results/mem_dnn-%s_xla-%s_c-%s_opt-%s.tsv'%(dnn, xla, config, opt)
				rname = 'results/rate_dnn-%s_xla-%s_c-%s_opt-%s.tsv'%(dnn, xla, config, opt)
				if not os.path.exists(fname):
					continue
				A = np.loadtxt(fname)
				rates = np.loadtxt(rname)
				mem[(dnn, xla, config, opt)] = A
				vdiff = np.diff(A)
				s1, s2, s3, s4, s5 = tuple(fivenum(vdiff[1:]).astype(np.int))
				out = '| %s | %s | %s | %s | %i | %i | %i | %i | %i | %i |'%(dnn, xla, config, opt, s1, s2, s3, s4, s5, int(np.median(rates)))
				print out
sys.exit()
				
				
for lstm, td in ((1,1),(1,2),(2,1)):
	mem[(lstm, td)] = np.loadtxt('mem_lstm-%i_td-%i.tsv'%(lstm, td))
	print mem[(lstm,td)]
# Plot data
plt.figure(figsize=(10,5))
plt.suptitle("Effect of Layers on Leakage")

plt.subplot(1, 2, 1)
plt.title("Memory Usage")
for lstm, td in ((1,1),(1,2),(2,1)):
	vals = mem[(lstm,td)]/1000.0
	X = np.arange(len(vals))
	plt.plot(X[1:], vals[1:], label="lstm=%i td=%i"%(lstm,td))
plt.legend(loc=2)
ticks = np.arange(1,21,2)
plt.xticks(ticks, ticks)
plt.xlim(left=0)
plt.xlabel("Batch")
plt.ylabel("MB")

plt.subplot(1, 2, 2)
plt.title("Memory Increase")
for lstm, td in ((1,1),(1,2),(2,1)):
	vals = mem[(lstm,td)]/1000.0
	vdiff = np.diff(vals)
	X = np.arange(len(vdiff))+0.5
	plt.plot(X[1:], vdiff[1:], label="lstm=%i td=%i"%(lstm,td))
plt.legend(loc=1)
plt.xticks(ticks, ticks)
plt.xlim(left=0)
plt.xlabel("Batch")
plt.ylabel("MB")

plt.tight_layout()
plt.savefig("effect.png")
