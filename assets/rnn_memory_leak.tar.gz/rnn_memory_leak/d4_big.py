import numpy as np
import tensorflow
from tensorflow.core.protobuf import rewriter_config_pb2
from tensorflow.keras.backend import set_session
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, TimeDistributed, Dense
from tensorflow.keras.optimizers import Adam
import resource, pprint, sys, os
from time import time

dnn, xla, c, opt = 'on', 'off', 'default', 'on'
if 'TF_XLA_FLAGS' in os.environ:
	xla = 'on'
if 'TF_DISABLE_MKL' in os.environ:
	dnn = 'off'
if len(sys.argv) > 1 and sys.argv[1] == 'custom':
	c = 'custom'
	config = tensorflow.ConfigProto(intra_op_parallelism_threads=24, \
		inter_op_parallelism_threads=2)
	#log_device_placement=False, allow_soft_placement=True)
else:
	config = tensorflow.ConfigProto()
if len(sys.argv) > 2 and sys.argv[2] == 'arith':
	opt = 'off'
	off = rewriter_config_pb2.RewriterConfig.OFF
	config.graph_options.rewrite_options.arithmetic_optimization = off
set_session(tensorflow.Session(config=config))
suff = 'big_dnn-%s_xla-%s_c-%s_opt-%s'%(dnn, xla, c, opt)

with open('config_%s.tsv'%(suff),'w') as OF:
	for k in dir(config):
		try:
			OF.write("%s\t%s\n"%(k, str(getattr(config,k))))
		except:
			pass

# Class for generating input and output data
class d4:
	def __init__(self):
		fair = np.ones(4)/4.0
		load = np.array([0.5, 0.3, 0.2, 0.0])
		self.dice = np.vstack((fair, load))
	def roll_gen(self, n):
		x, y = np.zeros((n,1), dtype=np.uint8), np.zeros((n,1), dtype=np.uint8)
		y[0] = np.random.choice(2)
		for i in range(n):
			x[i] = np.random.choice(4, replace=True, p=self.dice[y[i,0],:])
			if i < n-1:
				if i >= 1 and np.all(x[i-1:i+1] == 1):
					y[i+1] = 1 - y[i]
				else:
					y[i+1] = y[i]
		return x, y
	def roll_batch(self, n, b):
		x,y = np.zeros((b,n,1), dtype=np.uint8), np.zeros((b,n,1), dtype=np.uint8)
		for i in range(b):
			tx, ty = self.roll_gen(n)
			x[i,:,:] = tx
			y[i,:,:] = ty
		return x,y
# Helper function for creating model
def gen_model(n):
	model = Sequential()
	model.add(LSTM(128, return_sequences=True, input_shape=(n,1)))
	model.add(LSTM(128, return_sequences=True))
	model.add(TimeDistributed(Dense(128, activation='tanh')))
	model.add(TimeDistributed(Dense(1, activation='linear')))
	model.compile(loss='mean_squared_error', optimizer=Adam())
	return model

# Initialize model and data
seq_len = 200
batch_size = 200
epochs = 20
casino = d4()
model = gen_model(seq_len)
mem = np.zeros(epochs+1)
mem[0] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
# Run model
for e in range(epochs):
	xb, yb = casino.roll_batch(seq_len, batch_size)
	start = time()
	loss = model.train_on_batch(xb, yb)
	elapsed = time()-start
	rate = float(batch_size)/elapsed
	kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
	print "batch %02i - Max res size: %.0f MB     Change res size: %.2f MB     Loss: %.3f    Rate: %.1f seq/s "%(e+1, kb/1000.0, (kb-mem[e])/1000.0, loss, rate)
	mem[e+1] = kb
with open('mem_%s.tsv'%(suff),'w') as OF:
	for m in mem: OF.write('%f\n'%(m))
